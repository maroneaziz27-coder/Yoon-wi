"use client"

import { useState } from "react"
import { AppHeader } from "@/components/yoon-wi/app-header"
import { BottomNav, type ViewId } from "@/components/yoon-wi/bottom-nav"
import { HomeView } from "@/components/yoon-wi/views/home-view"
import { ReserveView } from "@/components/yoon-wi/views/reserve-view"
import { GpsView } from "@/components/yoon-wi/views/gps-view"
import { WalletView } from "@/components/yoon-wi/views/wallet-view"
import { useYoonWi } from "@/components/yoon-wi/store"

export function AppShell() {
  const [view, setView] = useState<ViewId>("home")
  const { userName } = useYoonWi()

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col gap-6 px-4 py-6">
      <AppHeader userName={userName} />

      <div className="flex-1">
        {view === "home" && <HomeView onNavigate={setView} />}
        {view === "reserve" && <ReserveView />}
        {view === "gps" && <GpsView />}
        {view === "wallet" && <WalletView />}
      </div>

      <BottomNav active={view} onChange={setView} />
    </main>
  )
}
