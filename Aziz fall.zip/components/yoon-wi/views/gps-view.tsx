"use client"

import { useEffect, useState } from "react"
import { MapPin, Navigation, Clock, Bus, CircleDot, Flag } from "lucide-react"
import { useYoonWi, formatDateFr } from "@/components/yoon-wi/store"

const STEPS = [
  { key: "dakar", label: "Dakar — Point de collecte" },
  { key: "rufisque", label: "Rufisque" },
  { key: "thies", label: "Thiès" },
  { key: "diourbel", label: "Diourbel" },
]

export function GpsView() {
  const { reservations } = useYoonWi()
  const active = reservations.find((r) => r.status !== "cancelled")

  const [progress, setProgress] = useState(0.35)

  // Simulate the vehicle moving along the route.
  useEffect(() => {
    const t = setInterval(() => {
      setProgress((p) => (p >= 1 ? 0.05 : +(p + 0.01).toFixed(2)))
    }, 1200)
    return () => clearInterval(t)
  }, [])

  const currentStep = Math.min(STEPS.length - 1, Math.floor(progress * STEPS.length))
  const etaMin = Math.max(2, Math.round((1 - progress) * 90))

  return (
    <div className="flex flex-col gap-6">
      <header>
        <h1 className="flex items-center gap-2 font-serif text-2xl font-bold text-foreground">
          <Navigation className="size-6 text-primary" aria-hidden="true" />
          Suivi GPS
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {active ? `Trajet vers ${active.destinationName}` : "Aucun trajet actif"}
        </p>
      </header>

      {/* Map area */}
      <div className="relative h-56 overflow-hidden rounded-3xl border border-border bg-secondary">
        {/* grid backdrop */}
        <div
          className="absolute inset-0 opacity-40"
          aria-hidden="true"
          style={{
            backgroundImage:
              "linear-gradient(to right, var(--border) 1px, transparent 1px), linear-gradient(to bottom, var(--border) 1px, transparent 1px)",
            backgroundSize: "28px 28px",
          }}
        />
        {/* route line */}
        <svg className="absolute inset-0 h-full w-full" viewBox="0 0 300 220" preserveAspectRatio="none" aria-hidden="true">
          <path
            d="M 30 180 C 90 160, 80 90, 150 90 S 230 60, 270 40"
            fill="none"
            stroke="var(--primary)"
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray="2 10"
            opacity="0.4"
          />
          <path
            d="M 30 180 C 90 160, 80 90, 150 90 S 230 60, 270 40"
            fill="none"
            stroke="var(--primary)"
            strokeWidth="4"
            strokeLinecap="round"
            pathLength={1}
            strokeDasharray={1}
            strokeDashoffset={1 - progress}
          />
        </svg>
        {/* start & end markers */}
        <div className="absolute bottom-8 left-6 flex items-center gap-1.5 rounded-full bg-card px-2.5 py-1 text-xs font-semibold text-foreground shadow">
          <CircleDot className="size-3.5 text-primary" aria-hidden="true" />
          Dakar
        </div>
        <div className="absolute right-4 top-4 flex items-center gap-1.5 rounded-full bg-primary px-2.5 py-1 text-xs font-semibold text-primary-foreground shadow">
          <Flag className="size-3.5" aria-hidden="true" />
          {active?.destinationName ?? "Village"}
        </div>
        {/* moving bus */}
        <div
          className="absolute flex size-9 items-center justify-center rounded-full bg-accent text-accent-foreground shadow-lg transition-all duration-1000 ease-linear"
          style={{
            left: `${8 + progress * 82}%`,
            top: `${78 - progress * 62}%`,
          }}
        >
          <Bus className="size-4" aria-hidden="true" />
        </div>
      </div>

      {/* ETA */}
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-2xl border border-border bg-card p-4">
          <p className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <Clock className="size-4 text-primary" aria-hidden="true" />
            Arrivée estimée
          </p>
          <p className="mt-1 font-serif text-2xl font-bold text-foreground">{etaMin} min</p>
        </div>
        <div className="rounded-2xl border border-border bg-card p-4">
          <p className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <MapPin className="size-4 text-primary" aria-hidden="true" />
            Progression
          </p>
          <p className="mt-1 font-serif text-2xl font-bold text-foreground">{Math.round(progress * 100)}%</p>
        </div>
      </div>

      {/* Steps */}
      <section aria-labelledby="steps-title">
        <h2 id="steps-title" className="mb-3 text-lg font-bold">
          Étapes du trajet
        </h2>
        <ol className="relative flex flex-col gap-4 pl-6">
          <span className="absolute left-[7px] top-1 h-[calc(100%-1rem)] w-0.5 bg-border" aria-hidden="true" />
          {STEPS.map((step, i) => {
            const done = i < currentStep
            const current = i === currentStep
            return (
              <li key={step.key} className="relative flex items-center gap-3">
                <span
                  className={
                    done || current
                      ? "absolute -left-6 flex size-4 items-center justify-center rounded-full bg-primary"
                      : "absolute -left-6 flex size-4 items-center justify-center rounded-full border-2 border-border bg-card"
                  }
                  aria-hidden="true"
                >
                  {current && <span className="size-1.5 rounded-full bg-primary-foreground" />}
                </span>
                <span
                  className={
                    current
                      ? "text-sm font-bold text-primary"
                      : done
                        ? "text-sm font-medium text-muted-foreground"
                        : "text-sm font-medium text-foreground"
                  }
                >
                  {step.label}
                  {current && <span className="ml-2 text-xs font-normal text-accent">• en cours</span>}
                </span>
              </li>
            )
          })}
        </ol>
      </section>

      {active && (
        <p className="rounded-2xl border border-border bg-secondary p-4 text-center text-sm text-muted-foreground">
          Départ prévu le <span className="font-semibold text-foreground">{formatDateFr(active.date)}</span> à{" "}
          <span className="font-semibold text-foreground">{active.time}</span>. Le chauffeur partage sa position en direct.
        </p>
      )}
    </div>
  )
}
