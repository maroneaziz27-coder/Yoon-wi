"use client"

import { useState } from "react"
import { Wallet, Plus, ArrowUpRight, ArrowDownLeft } from "lucide-react"
import { useYoonWi, formatFcfa } from "@/components/yoon-wi/store"

const QUICK_AMOUNTS = [500, 1000, 2000, 5000]

export function WalletView() {
  const { balance, transactions, topUp } = useYoonWi()
  const [amount, setAmount] = useState("")

  function handleTopUp(value: number) {
    if (value > 0) topUp(value)
  }

  function handleCustom(e: React.FormEvent) {
    e.preventDefault()
    const value = Number.parseInt(amount, 10)
    if (Number.isFinite(value) && value > 0) {
      topUp(value)
      setAmount("")
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <header>
        <h1 className="flex items-center gap-2 font-serif text-2xl font-bold text-foreground">
          <Wallet className="size-6 text-primary" aria-hidden="true" />
          Portefeuille
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">Yoon Wi Money — soldes et recharges.</p>
      </header>

      {/* Balance card */}
      <section className="relative overflow-hidden rounded-3xl bg-primary px-5 py-6 text-primary-foreground">
        <div
          className="pointer-events-none absolute -right-10 -top-10 size-36 rounded-full bg-primary-foreground/10"
          aria-hidden="true"
        />
        <p className="text-sm text-primary-foreground/80">Solde disponible</p>
        <p className="mt-1 font-serif text-4xl font-bold">{formatFcfa(balance)}</p>
        <p className="mt-3 text-xs text-primary-foreground/70">Portefeuille Yoon Wi • Aziz</p>
      </section>

      {/* Top up */}
      <section aria-labelledby="topup-title">
        <h2 id="topup-title" className="mb-3 flex items-center gap-2 text-lg font-bold">
          <Plus className="size-5 text-primary" aria-hidden="true" />
          Recharger
        </h2>
        <div className="mb-3 grid grid-cols-4 gap-2">
          {QUICK_AMOUNTS.map((v) => (
            <button
              key={v}
              type="button"
              onClick={() => handleTopUp(v)}
              className="rounded-xl border border-border bg-card py-3 text-sm font-semibold text-foreground transition-colors hover:border-primary hover:bg-secondary"
            >
              +{v.toLocaleString("fr-FR")}
            </button>
          ))}
        </div>
        <form onSubmit={handleCustom} className="flex gap-2">
          <input
            value={amount}
            onChange={(e) => setAmount(e.target.value.replace(/[^0-9]/g, ""))}
            placeholder="Autre montant (FCFA)"
            inputMode="numeric"
            className="w-full rounded-xl border border-border bg-card px-4 py-3 text-sm text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-ring/40"
          />
          <button
            type="submit"
            className="shrink-0 rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground transition-transform active:scale-95"
          >
            Recharger
          </button>
        </form>
      </section>

      {/* Transactions */}
      <section aria-labelledby="tx-title">
        <h2 id="tx-title" className="mb-3 text-lg font-bold">
          Historique
        </h2>
        <ul className="flex flex-col gap-2">
          {transactions.map((tx) => (
            <li key={tx.id} className="flex items-center justify-between rounded-2xl border border-border bg-card p-3.5">
              <div className="flex items-center gap-3">
                <span
                  className={
                    tx.type === "credit"
                      ? "flex size-9 items-center justify-center rounded-full bg-primary/15 text-primary"
                      : "flex size-9 items-center justify-center rounded-full bg-accent/20 text-accent"
                  }
                  aria-hidden="true"
                >
                  {tx.type === "credit" ? <ArrowDownLeft className="size-4" /> : <ArrowUpRight className="size-4" />}
                </span>
                <div>
                  <p className="text-sm font-semibold text-foreground">{tx.label}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(tx.at).toLocaleDateString("fr-FR", {
                      day: "numeric",
                      month: "short",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
              </div>
              <span
                className={
                  tx.type === "credit" ? "text-sm font-bold text-primary" : "text-sm font-bold text-foreground"
                }
              >
                {tx.type === "credit" ? "+" : "−"}
                {formatFcfa(tx.amount)}
              </span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  )
}
