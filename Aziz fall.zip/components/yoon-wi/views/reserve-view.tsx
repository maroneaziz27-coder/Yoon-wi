"use client"

import { useMemo, useState } from "react"
import { CalendarPlus, MapPin, Users, UserPlus, Trash2, CheckCircle2, AlertCircle } from "lucide-react"
import { useYoonWi, DESTINATIONS, formatFcfa, RESERVATION_FEE } from "@/components/yoon-wi/store"

export function ReserveView() {
  const { family, book, addFamilyMember, removeFamilyMember, balance } = useYoonWi()

  const [destinationId, setDestinationId] = useState(DESTINATIONS[0].id)
  const [date, setDate] = useState("2026-08-26")
  const [time, setTime] = useState("07:00")
  const [selected, setSelected] = useState<string[]>(["Aziz"])
  const [feedback, setFeedback] = useState<{ ok: boolean; message: string } | null>(null)

  // Add-member form
  const [newName, setNewName] = useState("")
  const [newRelation, setNewRelation] = useState("")
  const [newPhone, setNewPhone] = useState("")

  const destination = useMemo(
    () => DESTINATIONS.find((d) => d.id === destinationId) ?? DESTINATIONS[0],
    [destinationId],
  )

  const people = useMemo(() => ["Aziz", ...family.map((m) => m.name)], [family])

  function togglePassenger(name: string) {
    setSelected((prev) => (prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name]))
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const result = book({
      destinationId,
      date,
      time,
      seats: Math.max(1, selected.length),
      passengers: selected,
    })
    setFeedback(result)
    if (result.ok) {
      setSelected(["Aziz"])
    }
  }

  function handleAddMember(e: React.FormEvent) {
    e.preventDefault()
    if (!newName.trim()) return
    addFamilyMember({
      name: newName.trim(),
      relation: newRelation.trim() || "Proche",
      phone: newPhone.trim() || "—",
    })
    setNewName("")
    setNewRelation("")
    setNewPhone("")
  }

  return (
    <div className="flex flex-col gap-6">
      <header>
        <h1 className="flex items-center gap-2 font-serif text-2xl font-bold text-foreground">
          <CalendarPlus className="size-6 text-primary" aria-hidden="true" />
          Réserver
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">Voyage Yoonee Njaboot vers votre village.</p>
      </header>

      <form onSubmit={handleSubmit} className="flex flex-col gap-5">
        {/* Destination */}
        <div className="flex flex-col gap-2">
          <label htmlFor="destination" className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
            <MapPin className="size-4 text-primary" aria-hidden="true" />
            Destination
          </label>
          <select
            id="destination"
            value={destinationId}
            onChange={(e) => setDestinationId(e.target.value)}
            className="w-full rounded-xl border border-border bg-card px-4 py-3 text-sm font-medium text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-ring/40"
          >
            {DESTINATIONS.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.region}) — {formatFcfa(d.fare)}
              </option>
            ))}
          </select>
        </div>

        {/* Date & time */}
        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-2">
            <label htmlFor="date" className="text-sm font-semibold text-foreground">
              Date de départ
            </label>
            <input
              id="date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full rounded-xl border border-border bg-card px-3 py-3 text-sm font-medium text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-ring/40"
            />
          </div>
          <div className="flex flex-col gap-2">
            <label htmlFor="time" className="text-sm font-semibold text-foreground">
              Heure
            </label>
            <input
              id="time"
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full rounded-xl border border-border bg-card px-3 py-3 text-sm font-medium text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-ring/40"
            />
          </div>
        </div>

        {/* Passengers */}
        <fieldset className="flex flex-col gap-2">
          <legend className="mb-1 flex items-center gap-1.5 text-sm font-semibold text-foreground">
            <Users className="size-4 text-primary" aria-hidden="true" />
            Passagers ({selected.length} {selected.length > 1 ? "places" : "place"})
          </legend>
          <div className="flex flex-wrap gap-2">
            {people.map((name) => {
              const isOn = selected.includes(name)
              return (
                <button
                  key={name}
                  type="button"
                  onClick={() => togglePassenger(name)}
                  aria-pressed={isOn}
                  className={
                    isOn
                      ? "rounded-full border border-primary bg-primary px-3.5 py-1.5 text-sm font-semibold text-primary-foreground"
                      : "rounded-full border border-border bg-card px-3.5 py-1.5 text-sm font-medium text-foreground hover:border-primary/40"
                  }
                >
                  {name}
                </button>
              )
            })}
          </div>
        </fieldset>

        {/* Summary */}
        <div className="rounded-2xl border border-border bg-secondary p-4">
          <div className="flex items-center justify-between py-1 text-sm">
            <span className="text-muted-foreground">Tarif trajet ({destination.name})</span>
            <span className="font-semibold text-foreground">{formatFcfa(destination.fare)}</span>
          </div>
          <div className="flex items-center justify-between py-1 text-sm">
            <span className="text-muted-foreground">Frais de réservation</span>
            <span className="font-bold text-accent">{formatFcfa(RESERVATION_FEE)}</span>
          </div>
          <div className="mt-1 flex items-center justify-between border-t border-dashed border-border pt-2 text-sm">
            <span className="font-semibold text-foreground">À payer maintenant</span>
            <span className="font-serif font-bold text-primary">{formatFcfa(RESERVATION_FEE)}</span>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Solde portefeuille : <span className="font-semibold text-primary">{formatFcfa(balance)}</span> · Le tarif du
            trajet se règle à bord.
          </p>
        </div>

        {feedback && (
          <div
            role="status"
            className={
              feedback.ok
                ? "flex items-center gap-2 rounded-xl border border-primary/30 bg-primary/10 px-4 py-3 text-sm font-medium text-primary"
                : "flex items-center gap-2 rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm font-medium text-destructive"
            }
          >
            {feedback.ok ? (
              <CheckCircle2 className="size-4 shrink-0" aria-hidden="true" />
            ) : (
              <AlertCircle className="size-4 shrink-0" aria-hidden="true" />
            )}
            {feedback.message}
          </div>
        )}

        <button
          type="submit"
          className="flex items-center justify-center gap-2 rounded-full bg-primary py-3.5 text-base font-bold text-primary-foreground transition-transform active:scale-95"
        >
          <CheckCircle2 className="size-5" aria-hidden="true" />
          Confirmer la réservation
        </button>
      </form>

      {/* Family manager */}
      <section aria-labelledby="family-title" className="border-t border-border pt-5">
        <h2 id="family-title" className="mb-3 flex items-center gap-2 text-lg font-bold">
          <Users className="size-5 text-primary" aria-hidden="true" />
          Ma famille
        </h2>
        <ul className="mb-4 flex flex-col gap-2">
          {family.map((m) => (
            <li key={m.id} className="flex items-center justify-between rounded-2xl border border-border bg-card p-3.5">
              <div>
                <p className="text-sm font-semibold text-foreground">{m.name}</p>
                <p className="text-xs text-muted-foreground">
                  {m.relation} · {m.phone}
                </p>
              </div>
              <button
                type="button"
                onClick={() => removeFamilyMember(m.id)}
                aria-label={`Retirer ${m.name}`}
                className="flex size-9 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
              >
                <Trash2 className="size-4" aria-hidden="true" />
              </button>
            </li>
          ))}
        </ul>

        <form onSubmit={handleAddMember} className="flex flex-col gap-3 rounded-2xl border border-dashed border-border p-4">
          <p className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
            <UserPlus className="size-4 text-primary" aria-hidden="true" />
            Ajouter un membre
          </p>
          <input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Nom complet"
            className="w-full rounded-xl border border-border bg-card px-4 py-2.5 text-sm text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-ring/40"
          />
          <div className="grid grid-cols-2 gap-3">
            <input
              value={newRelation}
              onChange={(e) => setNewRelation(e.target.value)}
              placeholder="Lien (ex: Fils)"
              className="w-full rounded-xl border border-border bg-card px-4 py-2.5 text-sm text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-ring/40"
            />
            <input
              value={newPhone}
              onChange={(e) => setNewPhone(e.target.value)}
              placeholder="Téléphone"
              inputMode="tel"
              className="w-full rounded-xl border border-border bg-card px-4 py-2.5 text-sm text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-ring/40"
            />
          </div>
          <button
            type="submit"
            className="flex items-center justify-center gap-1.5 rounded-full border border-primary py-2.5 text-sm font-semibold text-primary transition-colors hover:bg-primary hover:text-primary-foreground"
          >
            <UserPlus className="size-4" aria-hidden="true" />
            Ajouter à la famille
          </button>
        </form>
      </section>
    </div>
  )
}
