"use client"

import { Bus, ClipboardList, CheckCircle2, Bell, Bot, Phone, CalendarPlus, MapPin, XCircle } from "lucide-react"
import { useYoonWi, formatFcfa, formatDateFr, RESERVATION_FEE } from "@/components/yoon-wi/store"
import type { ViewId } from "@/components/yoon-wi/bottom-nav"

export function HomeView({ onNavigate }: { onNavigate: (id: ViewId) => void }) {
  const { reservations, reminders, cancelReservation } = useYoonWi()
  const active = reservations.filter((r) => r.status !== "cancelled")
  const pendingReminders = reminders.filter((r) => !r.done)

  return (
    <div className="flex flex-col gap-6">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl bg-primary px-5 py-6 text-primary-foreground">
        <div
          className="pointer-events-none absolute -right-8 -top-10 size-32 rounded-full bg-primary-foreground/10"
          aria-hidden="true"
        />
        <div
          className="pointer-events-none absolute -bottom-12 -left-6 size-28 rounded-full bg-primary-foreground/5"
          aria-hidden="true"
        />
        <div className="relative flex flex-col items-center text-center">
          <div className="mb-3 flex size-12 items-center justify-center rounded-2xl bg-primary-foreground/15">
            <Bus className="size-6" aria-hidden="true" />
          </div>
          <h1 className="font-serif text-xl font-bold text-balance">Yoonee Njaboot</h1>
          <p className="mt-1 text-sm text-primary-foreground/80 text-pretty">Voyage en famille vers les villages</p>
          <span className="mt-4 inline-flex items-center rounded-full bg-accent px-4 py-1.5 text-sm font-bold text-accent-foreground">
            Réservation {formatFcfa(RESERVATION_FEE)}
          </span>
        </div>
      </section>

      {/* Quick actions */}
      <div className="grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => onNavigate("reserve")}
          className="flex flex-col items-center gap-2 rounded-2xl border border-primary bg-primary px-3 py-4 text-sm font-semibold text-primary-foreground transition-transform active:scale-95"
        >
          <CalendarPlus className="size-6" aria-hidden="true" />
          Nouvelle réservation
        </button>
        <button
          type="button"
          onClick={() => onNavigate("gps")}
          className="flex flex-col items-center gap-2 rounded-2xl border border-border bg-card px-3 py-4 text-sm font-semibold text-foreground transition-colors hover:border-primary/40 hover:bg-secondary"
        >
          <MapPin className="size-6 text-primary" aria-hidden="true" />
          Suivre GPS
        </button>
      </div>

      {/* Active reservations */}
      <section aria-labelledby="reservation-title">
        <h2 id="reservation-title" className="mb-3 flex items-center gap-2 text-lg font-bold">
          <ClipboardList className="size-5 text-primary" aria-hidden="true" />
          Mes réservations
        </h2>
        {active.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border bg-card p-6 text-center text-sm text-muted-foreground">
            Aucune réservation active. Appuyez sur « Nouvelle réservation » pour commencer.
          </div>
        ) : (
          <ul className="flex flex-col gap-3">
            {active.map((r) => (
              <li key={r.id} className="rounded-2xl border border-border bg-card p-4">
                <dl>
                  <div className="flex items-center justify-between border-b border-dashed border-border py-2.5">
                    <dt className="text-sm font-medium text-muted-foreground">Destination</dt>
                    <dd className="text-sm font-semibold text-foreground">
                      {r.destinationName} <span className="text-muted-foreground">({r.region})</span>
                    </dd>
                  </div>
                  <div className="flex items-center justify-between border-b border-dashed border-border py-2.5">
                    <dt className="text-sm font-medium text-muted-foreground">Type</dt>
                    <dd className="text-sm font-semibold text-primary">Yoonee Njaboot ({r.seats} places)</dd>
                  </div>
                  <div className="flex items-center justify-between border-b border-dashed border-border py-2.5">
                    <dt className="text-sm font-medium text-muted-foreground">Départ</dt>
                    <dd className="text-sm font-semibold text-foreground">
                      {formatDateFr(r.date)} • {r.time}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between border-b border-dashed border-border py-2.5">
                    <dt className="text-sm font-medium text-muted-foreground">Tarif trajet</dt>
                    <dd className="text-sm font-semibold text-foreground">{formatFcfa(r.fare)}</dd>
                  </div>
                  <div className="flex items-center justify-between border-b border-dashed border-border py-2.5">
                    <dt className="text-sm font-medium text-muted-foreground">Frais réservation</dt>
                    <dd className="text-sm font-bold text-accent">{formatFcfa(r.fee)}</dd>
                  </div>
                  <div className="flex items-center justify-between pt-2.5">
                    <dt className="text-sm font-medium text-muted-foreground">Statut</dt>
                    <dd className="flex items-center gap-1.5 text-sm font-semibold text-primary">
                      <CheckCircle2 className="size-4" aria-hidden="true" />
                      {r.status === "confirmed" ? "Confirmé" : "En attente"}
                    </dd>
                  </div>
                </dl>
                {r.passengers.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {r.passengers.map((p) => (
                      <span
                        key={p}
                        className="rounded-full bg-secondary px-2.5 py-1 text-xs font-medium text-secondary-foreground"
                      >
                        {p}
                      </span>
                    ))}
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => cancelReservation(r.id)}
                  className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-xl border border-destructive/30 py-2 text-sm font-semibold text-destructive transition-colors hover:bg-destructive/10"
                >
                  <XCircle className="size-4" aria-hidden="true" />
                  Annuler la réservation
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Reminders */}
      <section aria-labelledby="reminders-title">
        <h2 id="reminders-title" className="mb-3 flex items-center gap-2 text-lg font-bold">
          <Bell className="size-5 text-primary" aria-hidden="true" />
          Rappels
          {pendingReminders.length > 0 && (
            <span className="ml-1 rounded-full bg-accent px-2 py-0.5 text-xs font-bold text-accent-foreground">
              {pendingReminders.length}
            </span>
          )}
        </h2>
        {reminders.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-border bg-card p-4 text-center text-sm text-muted-foreground">
            Aucun rappel pour le moment.
          </p>
        ) : (
          <ul className="flex flex-col gap-2">
            {reminders.map((rem) => (
              <li key={rem.id} className="rounded-2xl border border-border bg-card p-3.5">
                <p className={`text-sm font-semibold ${rem.done ? "text-muted-foreground line-through" : "text-foreground"}`}>
                  {rem.title}
                </p>
                <p className="mt-0.5 text-xs text-muted-foreground">{rem.detail}</p>
                <p className="mt-1 text-xs font-medium text-primary">{rem.when}</p>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Assistants */}
      <section className="rounded-2xl border-l-4 border-primary bg-secondary p-4">
        <div className="mb-2.5 flex flex-wrap gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-chart-3 px-3 py-1 text-xs font-semibold text-primary-foreground">
            <Bot className="size-3.5" aria-hidden="true" />
            IA Yoon-IA
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-accent px-3 py-1 text-xs font-semibold text-accent-foreground">
            <Phone className="size-3.5" aria-hidden="true" />
            Service Koor
          </span>
        </div>
        <p className="text-sm leading-relaxed text-foreground">
          <span className="font-semibold">Rappel automatique :</span> notification à J-1.
          <br />
          <span className="font-semibold">Agent humain :</span> appel direct si non-confirmation.
        </p>
      </section>
    </div>
  )
}
