export function AppHeader({ userName }: { userName: string }) {
  return (
    <header className="flex items-center justify-between border-b border-border pb-4">
      <div className="flex items-baseline gap-1.5">
        <span className="font-serif text-2xl font-bold tracking-tight text-primary">Yoon Wi</span>
        <span className="text-2xl font-light text-accent">•</span>
      </div>
      <div className="flex items-center gap-2 rounded-full bg-primary px-3.5 py-1.5 text-sm font-semibold text-primary-foreground">
        <span
          className="flex size-5 items-center justify-center rounded-full bg-primary-foreground/20 text-xs"
          aria-hidden="true"
        >
          {userName.charAt(0)}
        </span>
        {userName}
      </div>
    </header>
  )
}
