"use client"

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react"

export type Destination = {
  id: string
  name: string
  region: string
  fare: number
}

export const DESTINATIONS: Destination[] = [
  { id: "touba", name: "Touba", region: "Diourbel", fare: 3500 },
  { id: "tivaouane", name: "Tivaouane", region: "Thiès", fare: 2500 },
  { id: "mbour", name: "Mbour", region: "Thiès", fare: 2000 },
  { id: "kaolack", name: "Kaolack", region: "Kaolack", fare: 4000 },
  { id: "saint-louis", name: "Saint-Louis", region: "Saint-Louis", fare: 5000 },
  { id: "ziguinchor", name: "Ziguinchor", region: "Casamance", fare: 8000 },
  { id: "thies", name: "Thiès", region: "Thiès", fare: 1500 },
  { id: "diourbel", name: "Diourbel", region: "Diourbel", fare: 3000 },
]

export const RESERVATION_FEE = 100

export type ReservationStatus = "confirmed" | "pending" | "cancelled"

export type Reservation = {
  id: string
  destinationId: string
  destinationName: string
  region: string
  date: string
  time: string
  seats: number
  passengers: string[]
  fare: number
  fee: number
  status: ReservationStatus
  createdAt: number
}

export type FamilyMember = {
  id: string
  name: string
  relation: string
  phone: string
}

export type Transaction = {
  id: string
  label: string
  amount: number
  type: "credit" | "debit"
  at: number
}

export type Reminder = {
  id: string
  title: string
  detail: string
  when: string
  done: boolean
}

type YoonWiState = {
  userName: string
  balance: number
  reservations: Reservation[]
  family: FamilyMember[]
  transactions: Transaction[]
  reminders: Reminder[]
}

type BookingInput = {
  destinationId: string
  date: string
  time: string
  seats: number
  passengers: string[]
}

type YoonWiContextValue = YoonWiState & {
  book: (input: BookingInput) => { ok: boolean; message: string }
  cancelReservation: (id: string) => void
  addFamilyMember: (member: Omit<FamilyMember, "id">) => void
  removeFamilyMember: (id: string) => void
  topUp: (amount: number) => void
  toggleReminder: (id: string) => void
}

const YoonWiContext = createContext<YoonWiContextValue | null>(null)

const uid = () => Math.random().toString(36).slice(2, 10)

const initialReservation: Reservation = {
  id: uid(),
  destinationId: "touba",
  destinationName: "Touba",
  region: "Diourbel",
  date: "2026-08-26",
  time: "07:00",
  seats: 4,
  passengers: ["Aziz", "Fatou", "Awa", "Modou"],
  fare: 3500,
  fee: RESERVATION_FEE,
  status: "confirmed",
  createdAt: Date.now(),
}

export function YoonWiProvider({ children }: { children: ReactNode }) {
  const [userName] = useState("Aziz")
  const [balance, setBalance] = useState(5450)
  const [reservations, setReservations] = useState<Reservation[]>([initialReservation])
  const [family, setFamily] = useState<FamilyMember[]>([
    { id: uid(), name: "Fatou Ndiaye", relation: "Épouse", phone: "77 123 45 67" },
    { id: uid(), name: "Awa Sow", relation: "Fille", phone: "78 234 56 78" },
    { id: uid(), name: "Modou Fall", relation: "Fils", phone: "76 345 67 89" },
  ])
  const [transactions, setTransactions] = useState<Transaction[]>([
    { id: uid(), label: "Recharge portefeuille", amount: 5000, type: "credit", at: Date.now() - 86400000 },
    { id: uid(), label: "Réservation Touba", amount: RESERVATION_FEE, type: "debit", at: Date.now() - 3600000 },
  ])
  const [reminders, setReminders] = useState<Reminder[]>([
    {
      id: uid(),
      title: "Départ pour Touba",
      detail: "Rendez-vous au point de collecte 30 min avant.",
      when: "25 Août 2026 • 07h00 (J-1)",
      done: false,
    },
    {
      id: uid(),
      title: "Confirmer la présence",
      detail: "Yoon-IA vous appellera pour confirmer les 4 places.",
      when: "24 Août 2026 • 18h00",
      done: false,
    },
  ])

  const book = useCallback<YoonWiContextValue["book"]>(
    (input) => {
      const destination = DESTINATIONS.find((d) => d.id === input.destinationId)
      if (!destination) return { ok: false, message: "Destination introuvable." }
      if (input.seats < 1) return { ok: false, message: "Sélectionnez au moins une place." }
      if (balance < RESERVATION_FEE) {
        return { ok: false, message: "Solde insuffisant pour les frais de réservation (100 FCFA)." }
      }

      const reservation: Reservation = {
        id: uid(),
        destinationId: destination.id,
        destinationName: destination.name,
        region: destination.region,
        date: input.date,
        time: input.time,
        seats: input.seats,
        passengers: input.passengers.filter(Boolean),
        fare: destination.fare,
        fee: RESERVATION_FEE,
        status: "confirmed",
        createdAt: Date.now(),
      }

      setReservations((prev) => [reservation, ...prev])
      setBalance((prev) => prev - RESERVATION_FEE)
      setTransactions((prev) => [
        { id: uid(), label: `Réservation ${destination.name}`, amount: RESERVATION_FEE, type: "debit", at: Date.now() },
        ...prev,
      ])
      setReminders((prev) => [
        {
          id: uid(),
          title: `Départ pour ${destination.name}`,
          detail: "Rappel automatique envoyé à J-1 par Yoon-IA.",
          when: `${formatDateFr(input.date)} • ${input.time}`,
          done: false,
        },
        ...prev,
      ])

      return { ok: true, message: `Réservation confirmée pour ${destination.name} !` }
    },
    [balance],
  )

  const cancelReservation = useCallback((id: string) => {
    setReservations((prev) => prev.map((r) => (r.id === id ? { ...r, status: "cancelled" } : r)))
  }, [])

  const addFamilyMember = useCallback((member: Omit<FamilyMember, "id">) => {
    setFamily((prev) => [...prev, { ...member, id: uid() }])
  }, [])

  const removeFamilyMember = useCallback((id: string) => {
    setFamily((prev) => prev.filter((m) => m.id !== id))
  }, [])

  const topUp = useCallback((amount: number) => {
    if (amount <= 0) return
    setBalance((prev) => prev + amount)
    setTransactions((prev) => [
      { id: uid(), label: "Recharge portefeuille", amount, type: "credit", at: Date.now() },
      ...prev,
    ])
  }, [])

  const toggleReminder = useCallback((id: string) => {
    setReminders((prev) => prev.map((r) => (r.id === id ? { ...r, done: !r.done } : r)))
  }, [])

  const value = useMemo<YoonWiContextValue>(
    () => ({
      userName,
      balance,
      reservations,
      family,
      transactions,
      reminders,
      book,
      cancelReservation,
      addFamilyMember,
      removeFamilyMember,
      topUp,
      toggleReminder,
    }),
    [
      userName,
      balance,
      reservations,
      family,
      transactions,
      reminders,
      book,
      cancelReservation,
      addFamilyMember,
      removeFamilyMember,
      topUp,
      toggleReminder,
    ],
  )

  return <YoonWiContext.Provider value={value}>{children}</YoonWiContext.Provider>
}

export function useYoonWi() {
  const ctx = useContext(YoonWiContext)
  if (!ctx) throw new Error("useYoonWi doit être utilisé dans un YoonWiProvider")
  return ctx
}

export function formatFcfa(amount: number) {
  return `${amount.toLocaleString("fr-FR").replace(/\u202f/g, " ")} FCFA`
}

export function formatDateFr(iso: string) {
  const d = new Date(`${iso}T00:00:00`)
  if (Number.isNaN(d.getTime())) return iso
  return d.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })
}
