"use client"

import { Home, CalendarPlus, MapPin, Wallet } from "lucide-react"
import { cn } from "@/lib/utils"

export type ViewId = "home" | "reserve" | "gps" | "wallet"

const tabs = [
  { id: "home", label: "Accueil", Icon: Home },
  { id: "reserve", label: "Réserver", Icon: CalendarPlus },
  { id: "gps", label: "GPS", Icon: MapPin },
  { id: "wallet", label: "Portefeuille", Icon: Wallet },
] as const

export function BottomNav({
  active,
  onChange,
}: {
  active: ViewId
  onChange: (id: ViewId) => void
}) {
  return (
    <nav
      aria-label="Navigation principale"
      className="sticky bottom-0 z-10 mt-2 flex items-center justify-around rounded-full border border-border bg-card/90 px-2 py-2 backdrop-blur"
    >
      {tabs.map(({ id, label, Icon }) => {
        const isActive = active === id
        return (
          <button
            key={id}
            type="button"
            onClick={() => onChange(id)}
            aria-current={isActive ? "page" : undefined}
            className={cn(
              "flex flex-1 flex-col items-center gap-1 rounded-full py-1.5 text-xs font-semibold transition-colors",
              isActive ? "text-primary" : "text-muted-foreground hover:text-foreground",
            )}
          >
            <span
              className={cn(
                "flex size-9 items-center justify-center rounded-full transition-colors",
                isActive ? "bg-primary text-primary-foreground" : "bg-transparent",
              )}
            >
              <Icon className="size-5" aria-hidden="true" />
            </span>
            {label}
          </button>
        )
      })}
    </nav>
  )
}
